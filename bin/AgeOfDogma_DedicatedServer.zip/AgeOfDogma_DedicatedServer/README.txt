You need to install ZEO DB for python if you want to run a dedicated server.
It can be found at:
https://pypi.org/project/ZEO/

Use start_server.bat to quickly setup your server

You may configure the following launch parameters:
Which port the server will run on:
--port

Which ip and port the ZEO database is located at, if you host your own DB, dbhost is localhost
--dbhost
--dbport

You may configure ZEO settings with the zeo.conf file