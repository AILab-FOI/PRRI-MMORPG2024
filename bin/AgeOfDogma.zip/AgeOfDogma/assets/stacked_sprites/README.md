# NOTICE

Stacked sprites of trees and animals are based on the ingenious [Moenen](https://moenen.artstation.com/) and their Voxel Collection. In order to use them you need to acquire the appropriate license and credit the original author for example [here](https://www.gamedevmarket.net/member/moenen).
