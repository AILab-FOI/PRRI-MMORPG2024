Use simple_launch.bat to launch the game.
You can modify simple_launch.bat to change your username and password.
Note, once you log in with a username, you cant change the password anymore.

Currently, you need to run your server locally, see AgeOfDogma_DedicatedServer for more info.

You can use the following launch parameters:
Username and password to register on the server
--username
--password

IP and PORT of the server you're connecting to
--server
--port